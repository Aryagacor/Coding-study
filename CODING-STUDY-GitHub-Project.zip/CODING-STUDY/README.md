# CODING STUDY

Starter project Android (Capacitor) dengan tema hitam-neon ungu.

## Build APK melalui GitHub Actions
1. Upload seluruh isi folder proyek ini ke repository GitHub (termasuk folder `.github`).
2. Buka tab **Actions**.
3. Pilih **Build CODING STUDY APK** lalu jalankan workflow, atau push ke branch `main`.
4. Setelah selesai, unduh artifact **CODING-STUDY-debug-apk**.

## Fitur yang sudah ada di starter
- Halaman awal login dan pendaftaran member lokal.
- Dashboard dengan banner anime dan logo pilihan.
- Jalur pengantar HTML, CSS, JavaScript, Python, C, C++, Java, SQL, Git/GitHub.
- Coding Playground HTML/CSS/JavaScript dengan preview.
- Simpan proyek, bookmark, riwayat, XP, backup/restore lokal.
- Tombol Hub Developer menuju WhatsApp 085928149092.
- Animasi tombol, card, dan skeleton shimmer style.

## Penting: batasan yang belum boleh dianggap selesai
Starter ini **belum** mengaktifkan backend multi-perangkat. Login member saat ini disimpan lokal di perangkat (untuk demo/offline), bukan autentikasi aman. Fitur admin untuk memantau semua member, leaderboard global, sertifikat terverifikasi, notifikasi push, dan sinkronisasi cloud memerlukan backend (misalnya Firebase) beserta konfigurasi proyek dan security rules. Jangan menanam password admin di APK atau GitHub. Jangan gunakan starter ini untuk menyimpan password penting atau data sensitif.

Code Playground menjalankan preview HTML/CSS/JavaScript dalam iframe sandbox. Python, C/C++, Java, dan SQL di materi adalah materi/contoh; compiler lokal untuk bahasa tersebut belum disertakan.

Materi di file ini adalah kerangka awal yang perlu diperluas menjadi bab lengkap, kuis, pembahasan, dan proyek bertahap sebelum disebut kurikulum penuh.
